# TSF-GRIP-Project-2020
In this GRIP Internship program offered by The Sparks Foundation, I have developed Social Media Integrated android application, where a user can login with Facebook and Google sign-in (Both). After successful login, details (example : Name, E-mail address, Profile picture ) of the user displayed on the second page.
